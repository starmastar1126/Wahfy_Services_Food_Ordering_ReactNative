// import I18n from "i18n-js";
// import * as RNLocalize from "react-native-localize";
// import ar from '../strings/ar'
// import en from '../strings/en'

// I18n.fallbacks = true;
// I18n.translations = { en, ar };
// // console.log(RNLocalize.getCurrencies());
// console.log( RNLocalize.findBestAvailableLanguage(Object.keys(I18n.translations) ));
// export default I18n;