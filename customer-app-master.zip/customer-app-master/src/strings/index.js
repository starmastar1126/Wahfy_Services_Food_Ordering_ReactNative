import ar from './ar'
import en from './en'
import LocalizedStrings from 'react-native-localization'
export default strings = new LocalizedStrings({ ar, en })
