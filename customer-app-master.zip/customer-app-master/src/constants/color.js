export const colors = {
  white: '#fff',
  black: '#000',

  placeholder: 'gray',

  //button
  buttonBG: 'orange',

  //login screen
  inputBG: '#dddddd',

  //home screen
  deliveryButtonBG: '#ab0000',
  takeAwayButtonBG: '#06870e'
};
