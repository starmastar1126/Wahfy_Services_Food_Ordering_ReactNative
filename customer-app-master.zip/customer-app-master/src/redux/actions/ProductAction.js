import {GET_PRODUCT, GET_EXTRAS, ADD_EXTRAS} from './types';
import {get_request} from '../../services/API';



// export const incermentCount = (item, cart) => {
//   const index = cart.findIndex(e => e.product.id === item.product.id);
//   cart[index].qty = index !== -1 ? item.qty + 1 : 0;

// };
