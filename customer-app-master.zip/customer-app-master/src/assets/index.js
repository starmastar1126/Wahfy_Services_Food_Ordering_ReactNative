export const images = {
  food: require('./images/food.jpeg'),
  food_1: require('./images/food_1.jpeg'),
  food_2: require('./images/food_2.jpeg'),
  food_3: require('./images/food_3.jpg'),
  food_4: require('./images/food_4.jpg'),
  food_5: require('./images/food_5.jpg'),
  emptyCart: require('./images/emptyCart.png'),
};
